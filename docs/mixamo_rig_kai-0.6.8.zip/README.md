# Mixamo Rig Kai

Mixamo Rig Kai is a Blender add-on forked from the original Mixamo Rig project created by BeyondDev (Tyler Walker).

This project is currently under active development. Kai focuses on flexible humanoid rig generation from editable Reference Skeletons, with safer iteration during character production.

## Features

- Reference Skeleton generation from bundled templates
- Reference Skeleton Mapping for non-standard humanoid skeletons
- Variable Spine support
- Variable Neck support
- Optional Shoulder support
- Flexible humanoid control rig generation
- Rebuild Rig workflow for safely regenerating generated rig data
- Modular Eye targets with combined and independent aim controls
- Modular Face controllers with normalized Shape Key drivers
- Improved support for production workflows where skeleton edits continue after rig generation

## Eye / Face Modules (Facial v0.1 Phase 2)

Facial modules are generated from the `Eye / Face Modules` panel after the body control rig is ready.

- **Eye Module** is generated from the explicit `Head Bone` field, independently of the active Pose/Edit bone and current mode. The field defaults to the saved Reference Mapping Head when available. It creates a rectangular `EyeTargetRoot`, circular `EyeTarget_L/R`, and internal `Eye_L/R` output bones using one-bone IK with editable X/Y/Z IK limits. An internal `EyeCenterPos` is placed between the outputs, and a Damped Track keeps the target frame facing that center. Character-eye transfer is delegated to ReNim; Kai owns the rotation outputs only.
- **Face Module** creates a face-layout UI for left/right Brow, Eyelid, Eye Expression, Outer Corner/Squint, Mouth Position, and Mouth Corner controls. Brow controls use green horizontal forms, Eye/Eyelid controls use red circular regions, and Mouth controls use a blue horizontal oval. Root frames live in a separate `CTRL_Face_Root` bone collection and enclose each corresponding region. Add one or more objects to `Face Meshes`, then generate the module.
- `FaceCtrlRigRoot` is the user-adjustable root for moving and scaling the entire Face UI to the character. Child controller drivers continue to read their own Local Space transforms.
- A single Kai Facial Channel can drive matching Shape Keys on multiple registered meshes. Missing Shape Keys are skipped per object, while existing non-Kai drivers are reported as conflicts and preserved.
- **Facial Shape Key Mapping** lets each registered Face Mesh map every built-in Kai Facial Channel to a chosen non-Basis Shape Key or to `None`. Auto Detect fills only empty mappings, while manual and invalid saved values remain visible for review.
- `None` is a normal unassigned state. Missing warnings are reserved for saved Shape Key names that no longer exist, while non-Kai Driver conflicts stop generation without overwriting user data.
- The Face UI is positioned and uniformly scaled from the mapped Head bone instead of Zhao-specific fixed coordinates. Regeneration preserves user-adjusted Root transforms and fitted controller positions.
- Eye and Face modules expose state-aware Generate / Regenerate actions and separate Remove operations. Removing the Face module preserves its Mesh list and per-object Shape Key Mapping.
- **Custom Face Control** creates user-defined `0..1` Local X sliders by selecting a target Shape Key; Kai assigns a stable Internal ID automatically and initializes the editable Display Name from the Shape Key name. Custom channels appear in the existing per-mesh Mapping UI and share its `None`, Missing, Conflict, Multi Mesh, and Driver safety behavior.
- Custom sliders use a fixed Bar, movable Knob, and fixed viewport Text label under `Face_CustomRoot` on the screen-right side of the Face UI. Their insertion order and fitted rest positions are stable across regeneration, while the Custom root retains independent Move and Scale adjustments.
- Removing an individual Custom Controller removes only its bone, Mapping entries, and Kai-generated Drivers. Removing the whole Face Module preserves Custom definitions and Mapping so regeneration can restore them.
- Viewport labels preserve Unicode Display Names, but glyph rendering quality depends on Blender's built-in font support; Kai does not add a runtime dependency on an external OS font or font file.
- Face controller values are read in Local Space, explicitly clamped to `0..1`, and sent through a centralized Kai Facial Channel-to-Shape Key mapping.
- `Head Follow` is an Armature Object custom property. It drives the Face root constraint without reading a descendant controller, avoiding the dependency cycle in the analyzed legacy rig.
- Controllers and anchors are non-deforming. Unused Location channels, Rotation, and Scale are locked; normalized Location limits are also applied symmetrically.

AIUEO is intentionally not owned by Facial v0.1. It remains available for a future shared PandaLip input contract. Eye Scale, Eye Highlight, Mouth Position Z Rotation, capture features, unused Shape Key auto-wiring, `-1..+1` sliders, 2D/4-direction Custom Controllers, and Custom Driver Expressions remain outside this phase.

## Reference Templates

Available templates:

- Humanoid Basic
- Humanoid Fingers

## Control Rig Workflow

A typical humanoid workflow is:

1. Create a Reference Skeleton from a bundled template.
2. Edit the Reference Skeleton as needed.
3. Configure the Reference Mapping.
4. Run Generate Rig.
5. If the Reference Skeleton changes later, run Rebuild Rig.

The Reference Skeleton is treated as the source of truth. Kai-generated rig data, such as controllers, helper bones, constraints, and control collections, can be reset and generated again.

## Rebuild Rig

Rebuild Rig regenerates a previously generated rig from the current Reference Skeleton.

Internally, Rebuild Rig runs:

1. Reset Generated Rig
2. Generate Rig

Reset Generated Rig removes Kai-generated rig data while keeping the Reference Skeleton and saved `kai_*` Mapping data. This allows the user to adjust Reference Skeleton bone positions, rolls, parenting, and connection settings, then rebuild the generated controls without recreating the entire setup from scratch.

Rebuild Rig is intended for humanoid workflows first. Future template types, such as quadrupeds or additional appendages, can build on the same reset-and-regenerate design.

## Safety Validation

Before Rebuild Rig resets the generated rig, Kai validates the saved Mapping data.

Rebuild checks:

- Required Mapping bones: `Hip`, `Chest`, and `Head`
- Optional Mapping bones: `Spine`, `Neck`, and `Shoulder`
- Reference Skeleton hierarchy changes
- Reference Skeleton `connected` state changes

If a required Mapping bone is missing, Rebuild Rig stops before Reset Generated Rig runs. This protects the existing generated rig from being removed when the saved Mapping is no longer valid.

If optional Mapping bones are missing, Kai shows a warning and ignores those missing optional entries for the rebuild.

If hierarchy or `connected` changes are detected, Kai shows a warning and continues. These warnings are intended to help the user notice structural Reference Skeleton edits before reviewing the rebuilt rig.

## Mapping Notes

Current behavior:

- Rebuild Rig uses the saved `kai_*` Mapping data.
- Mapping is not automatically rediscovered or updated.
- Newly added Spine or Neck bones are not automatically adopted by Rebuild Rig.
- To use newly added bones, the user must explicitly update the Mapping through Generate Rig or a future dedicated Mapping workflow.
- Automatic Mapping refresh and candidate confirmation UI are planned as a separate future stage.

This keeps Rebuild Rig predictable and avoids accidentally treating user-created or helper bones as part of the Reference Skeleton Mapping.

## Credits

Original Author: BeyondDev (Tyler Walker)

Kai Maintainer: Gonsaku

## Roadmap

Completed:

- Variable Spine Support
- Variable Neck Support
- Reference Skeleton Mapping
- Optional Shoulder Support
- Reference Bone Generator
- Reference Template System
- Humanoid Basic Template
- Humanoid Fingers Template
- Rebuild Rig
- Reset Generated Rig
- Rebuild Safety Validation
- Eye / Face Modules (Facial v0.1 Phase 1)
- Facial Shape Key Mapping (Facial v0.1 Phase 1.2)
- Custom Shape Key Controller Generator (Facial v0.1 Phase 2)

Planned:

- Refresh Mapping from Skeleton with candidate confirmation UI
- Quadruped Support
- Additional UI Improvements

## Changelog

### v0.6.8 Preview — Facial v0.1 Phase 2

- Added the Custom Shape Key Controller Generator MVP with a target Shape Key-based workflow, automatic Display Name initialization, and stable automatic Internal IDs
- Added PandaLip-inspired Slider Bar, movable `cs_switch` Knob, fixed Viewport Label, and `Face_CustomRoot` group fitting
- Integrated Custom channels with per-object Mapping, Multi Mesh, `None`, Missing, Conflict, individual removal, regeneration, and save/reopen persistence
- Made Slider Bars and Labels display-only and non-selectable while keeping the Knob as the `0..1` animation control
- Updated Custom Slider Knobs to the Zhao-reviewed `cs_switch` scale of `(1.0, 1.0, 0.25)`
- Added the Zhao-reviewed yellow normal/selected and cyan active Bone Color scheme to Custom Slider Knobs
- Matched the Zhao-reviewed Slider Bar scale `(0.45, 1.0, 0.01)` and cyan display color
- Increased viewport Label scale to `(0.4, 0.4, 0.4)` and matched its cyan display color
- Known limitation: Unicode Display Names are preserved, but viewport glyph quality depends on Blender's built-in font support
- Not included: `-1..+1` sliders, 2D controllers, 4-direction controllers, and Custom Driver Expressions

### 0.6.7 (Unreleased) — Custom Slider Selection Safety

- Added the supplied `cs_switch` Mesh to the internal `lib/cs.blend` Custom Shape library
- Changed Custom Slider Knobs from `cs_square` to the compact `cs_switch` shape
- Separated selectable Knobs into `CTRL_Face_Custom` and display-only Bars/Labels into `MCH_Face_CustomUI`
- Reinforced Bar and Label non-selection while keeping `Face_CustomRoot` selectable for group fitting

### 0.6.6 (Unreleased) — Facial v0.1 Phase 2 UI Polish

- Changed Custom Controller creation to start from a target Shape Key and auto-fill its Display Name
- Replaced user-entered Property IDs with stable per-rig `custom_NNN` Internal IDs
- Added PandaLip-inspired fixed Slider Bars, movable Knobs, and fixed viewport Text labels
- Added Display Name editing without changing Internal IDs, Bone identity, or Mapping
- Added safe label cleanup and restoration across individual removal, Face removal, regeneration, and save/reopen

### 0.6.5 — Facial v0.1 Phase 2

- Added user-defined Custom Facial Channels with separate Property IDs and Display Names
- Added reusable `0..1` Local X slider generation under `Face_CustomRoot`
- Added a persistent Custom Controller list with add, select, and individual remove operations
- Integrated Custom channels into the existing per-object Shape Key Mapping UI
- Reused Phase 1.2 `None`, Missing, Conflict, Multi Mesh, and explicit Driver clamp handling
- Preserved Custom definitions and Mapping through Face Module removal and regeneration
- Preserved `Face_CustomRoot` Move/Scale and existing Custom Controller rest positions during regeneration
- Added schema 1 Custom definition storage without changing the existing Mapping schema 2 contract
- Kept signed sliders, 2D controls, custom expressions, and viewport Text Objects outside the MVP

### v0.6.4 Preview — Facial v0.1 Phase 1.2

- Added per-Face-Mesh Shape Key Mapping UI for all 40 built-in Kai Facial Channels
- Added searchable Shape Key selection with `None`, Missing, and non-Kai Driver Conflict states
- Changed Auto Detect into a safe empty-field-only mapping initializer
- Added schema 2 migration that preserves valid v0.6.3 connections and clears nonexistent legacy defaults
- Added safe Driver cleanup when mappings are changed, invalidated, or set to `None`
- Replaced Zhao-specific fixed Face UI sizing with a shared Head-based scale and initial placement
- Added Generate / Regenerate labels based on complete, partial, or missing module state
- Split Eye and Face removal into independent operations
- Preserved Face Mesh and Shape Key Mapping settings when removing and recreating the Face module
- Fixed the Shape Key search operator to return Blender's required modal result from `invoke()`
- Kept the Phase 2 Custom Shape Key Controller Generator outside this release

### v0.6.3 Preview — Facial v0.1 Phase 1.1

- Added independent Eye and Face modules
- Added combined and per-eye Aim targets with ReNim-readable `Eye_L/R` rotation outputs
- Added 15 Face controllers and declarative generation for 40 mapped Shape Key drivers
- Added symmetric Transform Locks and Local Location limits on facial controllers
- Fixed the legacy right Mouth Corner limit asymmetry and Eyelid Sad close-axis mismatch
- Replaced the cyclic descendant-driven Head Follow setup with an Armature Object property
- Reworked the Eye viewport UI into a rectangular group frame with circular left/right targets
- Changed Eye generation to use the selected Head bone and one-bone IK outputs with editable IK limits
- Added `EyeCenterPos` and an `EyeTargetRoot` Damped Track matching the original target-frame behavior
- Replaced active Pose/Edit bone detection with a rig-specific `Head Bone` field initialized from Reference Mapping
- Restored `FaceCtrlRigRoot` as a user-adjustable Move/Scale root
- Reworked the Face viewport language into color-coded Brow, Eye/Eyelid, and Mouth regions with separately displayable Root frames
- Added the `cs_switch_Arrow` library shape for the left/right Close-to-Smile blend controls
- Adopted the production-tested Face controller positions and Custom Shape scales from `Zhao.proto.ui.blend`
- Adopted the production-tested Eye controller colors and Custom Shape scales from `Zhao.proto.ui.blend`
- Added a standard multi-mesh Face target list and per-object channel mappings
- Added one-channel-to-many-mesh Driver generation with per-object missing-key skipping
- Kept AIUEO and the Custom Shape Key Controller Generator outside Phase 1

### v0.6.1 Preview

Bug fix release for Neck / Head retarget baking with Reference Mapping.

- Fixed duplicate prefix application when saved Neck / Head Mapping names already include a prefix
- Unified Neck / Head source bone resolution with the prefix-safe resolver used by Hip / Spine / Chest
- Fixed Neck / Head controllers being omitted from retarget and bake targets, which prevented animation keyframes from being generated
- Improved resolution for unprefixed, prefixed, cross-prefix, and custom Neck / Head Mapping names

### v0.6.0 Preview

Feature release for Retarget Bake rotation output and Kai default controller rotation modes.

- Added Retarget Bake Rotation Output options: `Quaternion`, `Euler`, and `Target Original`
- Set `Quaternion` as the default retarget rotation output
- Added Quaternion bake output using `rotation_quaternion` F-curves without generating `rotation_euler` F-curves
- Added quaternion sign compatibility correction to avoid curve jumps between frames
- Improved `Target Original` so it preserves each target controller's pre-bake rotation mode, including mixed Euler and Quaternion rigs
- Updated Kai default control rig rotation modes: `Ctrl_Master` uses XYZ Euler, while other `mixamo_ctrl` controllers use Quaternion
- Preserved existing controller rotation modes during Refresh, Reconnect, and Retarget setup so user changes are not reset to XYZ Euler

### v0.5.1 Preview

Bug fix release for the v0.5.0 Preview retarget regression.

- Fixed the Hips / Spine / Chest retarget regression
- Improved prefix-safe Mapping name resolution
- Unified bone name resolution between Rebuild and Retarget
- Improved Hip Mapping support so mapped hips such as `Pelvis` can receive Copy Location constraints
- Added retarget debug logging for missing source and target bones

### v0.5.0 Preview

- Added Rebuild Rig
- Added Reset Generated Rig
- Added generated bone and constraint tracking for safe rig reset
- Added Rebuild safety validation for required and optional Mapping data
- Added hierarchy and connected-state change warnings before Rebuild

### v0.4.0 Preview

- Reference Bone Generator
- Humanoid Basic Template
- Humanoid Fingers Template
- Template Selection UI
- Reference Template Validation Tools

### v0.3.0 Preview

- Optional Shoulder Support
- Support for shoulder-less humanoid skeletons
- Updated Reference Mapping workflow
- Additional Rig Generation improvements
